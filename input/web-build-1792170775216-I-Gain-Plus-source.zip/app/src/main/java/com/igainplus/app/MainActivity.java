package com.igainplus.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private int points;
    private TextView pointsView, statusView;
    private SharedPreferences prefs;
    private LinearLayout root;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("igain", MODE_PRIVATE);
        points = prefs.getInt("points", 0);
        buildUi();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String s, int size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(dp(2), dp(5), dp(2), dp(5));
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        return b;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(246, 248, 252));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("I-Gain+", 30, true, Color.rgb(20, 90, 70));
        root.addView(title);
        root.addView(text("Earn points • Daily check-in • Tasks", 15, false, Color.DKGRAY));

        LinearLayout wallet = new LinearLayout(this);
        wallet.setOrientation(LinearLayout.VERTICAL);
        wallet.setPadding(dp(18), dp(15), dp(18), dp(15));
        wallet.setBackgroundColor(Color.WHITE);
        root.addView(wallet, marginParams(-1, -2, 0, 18));
        wallet.addView(text("MY WALLET", 13, true, Color.GRAY));
        pointsView = text(points + " points", 28, true, Color.rgb(20, 90, 70));
        wallet.addView(pointsView);
        wallet.addView(text("Demo balance only — not real money.", 12, false, Color.GRAY));

        root.addView(text("Daily Check-in", 20, true, Color.BLACK));
        Button check = button("Claim daily 10 points");
        root.addView(check, marginParams(-1, -2, 0, 14));
        check.setOnClickListener(v -> {
            String today = new java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US)
                    .format(new java.util.Date());
            if (prefs.getString("last_checkin", "").equals(today)) {
                Toast.makeText(this, "Today's check-in is already claimed.", Toast.LENGTH_SHORT).show();
            } else {
                points += 10;
                prefs.edit().putInt("points", points).putString("last_checkin", today).apply();
                updatePoints();
                Toast.makeText(this, "10 demo points added!", Toast.LENGTH_SHORT).show();
            }
        });

        root.addView(text("Tasks", 20, true, Color.BLACK));
        root.addView(text("Complete a sample task to try the app.", 14, false, Color.DKGRAY));
        Button task = button("Complete sample task (+5 points)");
        root.addView(task, marginParams(-1, -2, 0, 16));
        task.setOnClickListener(v -> {
            points += 5;
            prefs.edit().putInt("points", points).apply();
            updatePoints();
            Toast.makeText(this, "5 demo points added!", Toast.LENGTH_SHORT).show();
        });

        root.addView(text("UPI Withdrawal Request", 20, true, Color.BLACK));
        root.addView(text("This demo records no payment and does not transfer money.", 13, false, Color.GRAY));
        EditText upi = new EditText(this);
        upi.setSingleLine(true);
        upi.setHint("Your UPI ID (demo only)");
        upi.setInputType( android.text.InputType.TYPE_CLASS_TEXT );
        root.addView(upi, marginParams(-1, -2, 0, 8));
        EditText amount = new EditText(this);
        amount.setSingleLine(true);
        amount.setHint("Points to request");
        amount.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        root.addView(amount, marginParams(-1, -2, 0, 8));
        Button request = button("Submit demo request");
        root.addView(request, marginParams(-1, -2, 0, 12));
        statusView = text("No request submitted.", 13, false, Color.DKGRAY);
        root.addView(statusView);

        request.setOnClickListener(v -> {
            String id = upi.getText().toString().trim();
            String a = amount.getText().toString().trim();
            if (id.isEmpty() || !id.contains("@") || a.isEmpty()) {
                Toast.makeText(this, "Enter a demo UPI ID and points amount.", Toast.LENGTH_SHORT).show();
                return;
            }
            statusView.setText("Demo request saved on this phone: " + a + " points. No money was sent.");
            prefs.edit().putString("last_request", a + " points to " + id).apply();
            Toast.makeText(this, "Demo request recorded.", Toast.LENGTH_SHORT).show();
        });

        root.addView(text("Version 1.0 • Starter demo", 12, false, Color.GRAY));
    }

    private LinearLayout.LayoutParams marginParams(int w, int h, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top); p.bottomMargin = dp(bottom);
        return p;
    }

    private void updatePoints() { pointsView.setText(points + " points"); }
}
